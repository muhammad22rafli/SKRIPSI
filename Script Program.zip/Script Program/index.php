<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
    <img src="assets/picture/Teksma1.png" width=200px style="display: block; margin : auto;">
    <?php
    if (isset($_GET['pesan'])) {
        if ($_GET['pesan'] == "gagal") {
            echo "<div class='alert'>Username dan Password tidak sesuai !</div>";
        }
    }
    ?>
    <div class="kotak_login">
        <p class="tulisan_login">Silahkan login</p>
        <form action="CekLogin.php" method="post">
            <label>Username</label>
            <input type="text" name="username" class="form_login" placeholder="Username .." autocomplete="off"required="required">

            <label>Password</label>
            <input type="password" name="password" class="form_login" placeholder="Password .." autocomplete="off" required="required">

            <input type="submit" class="tombol_login" value="LOGIN">
        </form>
    </div>
</body>
</html>