<?php 
$id = $_GET['id'];
$sql_read="SELECT * FROM surat_masuk WHERE id = $id";
$query_read=mysqli_query($koneksi, $sql_read);
$row = mysqli_fetch_assoc($query_read);
?>
<!-- Page Content-->
<div class="container-fluid p-0">
<!-- About-->
<section class="resume-section">
<div class="resume-section-content">
<h2>File Surat Masuk</h2>
<p>Nomor Surat : <?php echo $row['No_Surat'];?></p>
<p>Perihal : <?php echo $row['Perihal'];?></p>
<p>Asal Surat : <?php echo $row['Asal_Surat'];?></p>
<p>Tanggal Surat : <?php echo $row['Tgl_Surat'];?></p>
<p>Tanggal Diterima : <?php echo $row['Tgl_diterima'];?></p>
<p>Penerima : <?php echo $row['Penerima'];?></p>
<img src="File/<?php echo $row['File_Surat']; ?>" class="imgthumbnail">
</div>
</section>
</div>