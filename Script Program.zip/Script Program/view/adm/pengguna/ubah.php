<?php
    $id=$_GET['id']; 
    @$nama     = $_POST['nama'];
    @$Username = $_POST['username'];
    @$Password = $_POST['password'];
    @$Role = $_POST['role'];
    @$simpan = $_POST['simpan'];

    if ($simpan) {
        $sql="UPDATE data_user SET nama='$nama', username='$Username', password='$Password', role='$Role' WHERE id='$id'";
        $query=mysqli_query($koneksi, $sql);
        $_SESSION['berhasil'] = "Data Pengguna berhasil diubah";
        header('location:?page=user');
        }
        $sql_read="SELECT * FROM data_user WHERE id='$id'";
        $query_read=mysqli_query($koneksi, $sql_read);
        $row=mysqli_fetch_assoc($query_read);
        ?> 
     <div class="panel panel-default">
     <div class="panel-heading">
         Ubah Data Pengguna
     </div>
     <div class="panel-body">

         <div class="row">
             <div class="col-md-12">

                 <form method="POST">
                    <div class="form-group">
                         <label>Nama Lengkap</label>
                         <input class="form-control" name="nama" value="<?php echo 
                         $row['nama'] ?>" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Username</label>
                         <input class="form-control" name="username" value="<?php echo 
                         $row['username'] ?>" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Password</label>
                         <input class="form-control" name="password" value="<?php echo 
                         $row['password'] ?>" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Role</label>
                         <input class="form-control" name="role" value="<?php echo 
                         $row['role'] ?>"required autocomplete="off"/>
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>

 