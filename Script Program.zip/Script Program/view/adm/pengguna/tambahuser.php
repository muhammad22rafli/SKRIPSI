<div class="panel panel-default">
     <div class="panel-heading">
         Tambah User
     </div>
     <div class="panel-body">

         <div class="row">
             <div class="col-md-12">

                 <form method="POST">

                      <div class="form-group">
                         <label>Nama Lengkap</label>
                         <input class="form-control" name="nama" autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Username</label>
                         <input class="form-control" name="username" autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Password</label>
                         <input class="form-control" name="password" autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Level Pengguna</label>
                         <input class="form-control" name="role" autocomplete="off">
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>

 <?php

    @$simpan = $_POST['simpan'];
    @$nama   = $_POST['nama'];
    @$username = $_POST['username'];
    @$password = $_POST['password'];
    @$role = $_POST['role']; 

    if ($simpan) {
        $sql = $koneksi->query("insert into data_user(nama,username,password,role)values('$nama','$username','$password','$role')");

        if ($sql) {
    ?>
         <script type="text/javascript">
             alert("Data Berhasil di Simpan");
             window.location.href = "?page=user";
         </script>
 <?php
        }
    }

    ?>