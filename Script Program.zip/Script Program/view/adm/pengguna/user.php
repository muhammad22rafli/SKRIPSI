<div class="row">
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                DATA PENGGUNA
            </div>
            <a href="?page=user&aksi=tambah" class="btn btn-primary" style="margin-top: 8px;"><i class="fa fa-plus"></i> Tambah Data </a>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Lengkap</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Role</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php

                            $no = 1;
                            $sql = $koneksi->query("select * from data_user");
                            while ($data = $sql->fetch_assoc()) {

                            ?>
                                    <td><?=$no++; ?></td>
                                    <td><?=$data['nama']; ?></td>
                                    <td><?=$data['username']; ?></td>
                                    <td><?=$data['password']; ?></td>
                                    <td><?=$data['role']; ?></td>
                                    <td>
                                        <a href="?page=user&aksi=ubah&id=<?php echo $data["id"];?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Ubah </a>
                                        <a onclick="return confirm ('Anda yakin akan Menghapus data ini ?')" href="?page=user&aksi=hapus&id=<?php echo $data['id']; ?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus </a>
                                        
                                    </td>
                                </tr>
                                <?php } ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

