<?php
    $id=$_GET['id']; 
    @$No_Surat = $_POST['No_Surat'];
    @$Perihal = $_POST['Perihal'];
    @$Tujuan = $_POST['Tujuan'];
    @$Tgl_Surat = $_POST['Tgl_Surat'];
    @$Penanggung = $_POST['Penanggung_Jawab'];
    @$file = $_POST['File_Surat'];
    @$simpan = $_POST['simpan'];

    @$direktori = "File/Surat Keluar/";
    @$file = $_FILES['File_Surat']['name'];
    @$data = move_uploaded_file($_FILES['File_Surat']['tmp_name'],$direktori.$file);

    if ($simpan) {
        $sql="UPDATE surat_keluar SET No_Surat='$No_Surat', Perihal='$Perihal', Tujuan='$Tujuan', Tgl_Surat='$Tgl_Surat', Penanggung_Jawab='$Penanggung', File_Surat='$file' WHERE id='$id'";
        $query=mysqli_query($koneksi, $sql);
        $_SESSION['berhasil'] = "Surat Keluar berhasil diubah";
        header('location:?page=suratkeluar');
        }
        $sql_read="SELECT * FROM surat_keluar WHERE id='$id'";
        $query_read=mysqli_query($koneksi, $sql_read);
        $row=mysqli_fetch_assoc($query_read);
        ?>

 <div class="panel panel-default">
     <div class="panel-heading">
         Ubah Data Surat Keluar
     </div>
     <div class="panel-body">

         <div class="row">
             <div class="col-md-12">

                 <form method="POST" enctype="multipart/form-data">
                     <div class="form-group">
                         <label>Nomor Surat</label>
                         <input class="form-control" name=No_Surat value="<?php echo 
                         $row['No_Surat'] ?>" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Perihal</label>
                         <input class="form-control" name="Perihal" value="<?php echo 
                         $row['Perihal'] ?>" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Tujuan Surat</label>
                         <input class="form-control" name="Tujuan" value="<?php echo 
                         $row['Tujuan'] ?>" required autocomplete="off">
                        </select>
                     </div>

                      <div class="form-group">
                         <label>Tanggal Surat</label>
                         <input class="form-control" name="Tgl_Surat" type="date"  value="<?php echo 
                         $row['Tgl_Surat'] ?>" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Penanggung Jawab</label>
                         <input class="form-control" name="Penanggung_Jawab" value="<?php echo 
                         $row['Penanggung_Jawab'] ?>" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>File Surat</label>
                         <input type="File" class="form-control" name="File_Surat"  value="<?php echo $row['File_Surat'] ?>" required autocomplete="off" /> 
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>