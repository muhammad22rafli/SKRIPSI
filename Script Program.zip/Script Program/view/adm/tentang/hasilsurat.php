<!DOCTYPE html>
<html>
<head>
  <title>Surat Keterangan Kuliah</title>
  <style type="text/css">
    body{
      }
    @media print{
      .print{
        display: none;
      }
    }
    table {
      border-style: double;
      border-width: 3px;
      border-color: white;
    }
    table tr .text2 {
      text-align: right;
      font-size: 15px;
    }
    table tr .text {
      text-align: center;
      font-size: 20px;
    }
    table tr td {
      font-size: 13px;
    }
    table tr .text3 {
      text-align: left;
      font-size: 15px;
    }

  </style>
</head>
<body>
  <center>
    <table>
      <tr>
        <td><img src="assets/picture/Picture1.png" width="90" height="90"></td>
        <td>
        <center>
          <font size="5"><b>UNIVERSITAS BALE BANDUNG</b></font><br>
          <font size="4"><b>FAKULTAS TEKNOLOGI INFORMASI</b></font><br>
          <font size="2">PROGRAM STUDI : TEKNIK INFORMATIKA DAN SISTEM INFORMASI</font><br>
          <font size="2">JL. R.A.A. WIRANATAKUSUMAH No. 7 BALEENDAH KAB. BANDUNG 40258 Tlp. 022-5940443,5949221, Fax. 022-5940443</font>
        </center>
        </td>
      </tr>
      <tr>
        <td colspan="2"><hr></td>
      </tr>
  </br>
    <table>
      <tr>
        <table width="625">
          <td class text ="3" text align="left">
          <table width="425"><tr><td>Nomor</td><td> : </td><td>.../S.Pen/FTI-UNIBBA/III/2020</td></tr> 
          <tr><td>Lampiran</td><td>  : </td><td>-</td></tr>
          <tr><td>Hal</td><td>  : </td><td>Permohonan Ijin Kerja Praktek</td></tr>
          </font>
    </table>
  </td>
</tr>
  </table>
  </br>
    <table>
      <tr>
        <table width="625">
        <td class text ="3" text align="left">
          <font size ="2">Kepada<br></font>
           <?php
             $id = $_GET ['id'];
             $sql = $koneksi->query("select * from surat_peng_skripsi where id ='$id'");
             while ($data = $sql->fetch_assoc()) { 
              ?> 
          <font size ="2">Yth. Kepala Sekolah <?=$data['alamat_instansi_tujuan']; ?> <br></font>
        <?php } ?>
          <font size ="2">di <br></font>
          <font size ="2">Tempat <br></font>
        </td>
        </tr></br>
      </table>
      <tr>
      <br>
      <br>
      <table width="625">
        <td class text ="3" text align="left">
          <font size ="2">Dengan Hormat,<br></font>
        </td>
      </table>
    </tr>
    <br>
    <table width="625">
        <td class text ="3" text align="left">
          <font size ="2">Dalam rangka melaksanakan kerja praktek di lingkungan Universitas Bale Bandung. Dengan ini kami memohon perkenannya memberikan kesempatan kepada mahasiswa kami untuk melaksanakan kerja praktek di instansi bapak atau ibu.<br></font>
        </td>
      </table>
    </tr>
    <table>
              <table width="625">
                <font size ="3">
             <?php
             $id = $_GET ['id'];
             $sql = $koneksi->query("select * from surat_peng_skripsi where id ='$id'");
             while ($data = $sql->fetch_assoc()) { 
              ?> 
        <table>
          <table width ="625">
          <td class text ="3" text align="left"> 
          <table width="225"><tr><td>Nama </td><td>:</td><td> <?=$data['nama']; ?></td></tr> 
          <tr><td>NIM</td><td> : </td><td> <?=$data['nim']; ?></td></tr>
          <tr><td>Topik</td><td>: </td><td> <?=$data['topik']; ?></td></tr>
          </table>
          </table>
        </font>
      </table>
        </table>
    <?php } ?>
    
    </tbody>
    </table>
    <table>
    <br>
    <table width="625">
      <tr>
           <td>
             <font size="2">Demikian permohonan kami. Atas perhatian dan kebijaksanaannya diucapkan terima kasih.
            </font>
           </td>
        </tr>
    </table>
    <br>
    <table width="625">
      <tr>
        <td width="430"><br><br><br><br></td>
        <td class="text3" align="center">Baleendah, <?php echo date ('d M Y'); ?> &nbsp; <br>Dekan,<br><br><br><br>Yudi Herdiana S.T,.M.T.<br>NIK: 04104808008</td>
      </tr>
       </table>
  </center>
</table>
</font>
 <a  href="" onclick="window.print();"><button class="print">CETAK</button></a>
</body>
</html>