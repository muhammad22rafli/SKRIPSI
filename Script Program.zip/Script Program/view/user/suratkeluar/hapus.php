<?php
	
	$id=$_GET ['id'];
	$koneksi->query("delete from surat_keluar where id ='$id'");

?>
<script type="text/javascript">
	alert("Data Berhasil Dihapus")
	window.location.href="?page=suratkeluar";

</script>      