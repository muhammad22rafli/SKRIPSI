 <div class="panel panel-default">
     <div class="panel-heading">
         Tambah Data Surat Masuk
     </div>
     <div class="panel-body">

         <div class="row">
             <div class="col-md-12">

                 <form method="POST" enctype="multipart/form-data">
                     <div class="form-group">
                         <label>Nomor Surat</label>
                         <input class="form-control" name="No_Surat" required autocomplete="off" />
                     </div>

                     <div class="form-group">
                         <label>Perihal</label>
                         <input class="form-control" name="Perihal" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>Asal Surat</label>
                         <input class="form-control" name="Asal_Surat" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Tanggal Surat</label>
                         <input class="form-control" name="Tgl_Surat" type="date" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>Tanggal Diterima</label>
                         <input class="form-control" name="Tgl_diterima" type="date" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>Penerima</label>
                         <input class="form-control" name="Penerima" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>File Surat</label>
                         <input type="File" class="form-control" name=NamaFile required autocomplete="off" /> 
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>

 <?php

    if(isset($_POST['simpan'])){

    $No_Surat      = $_POST['No_Surat'];
    $Perihal       = $_POST['Perihal'];
    $Asal_Surat    = $_POST['Asal_Surat'];
    $Tgl_Surat     = $_POST['Tgl_Surat'];
    $Tgl_diterima  = $_POST['Tgl_diterima'];
    $Penerima      = $_POST['Penerima'];
    $file_name     = $_POST['NamaFile'];
      
    $direktori = "File/Surat Masuk/";
    $file_name = $_FILES['NamaFile']['name'];
    move_uploaded_file($_FILES['NamaFile']['tmp_name'],$direktori.$file_name);

        $Simpan = $koneksi->query("insert into surat_masuk(No_Surat,Perihal,Asal_Surat,Tgl_Surat,Tgl_diterima,Penerima,File_Surat)values('$No_Surat','$Perihal','$Asal_Surat','$Tgl_Surat','$Tgl_diterima','$Penerima','$file_name')");

        if ($Simpan) {
    ?>
         <script type="text/javascript">
             alert("Data Berhasil di Simpan");
             window.location.href = "?page=suratmasuk";
         </script>
 <?php
        }
    }

    ?>