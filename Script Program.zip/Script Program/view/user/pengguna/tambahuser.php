 <div class="panel panel-default">
     <div class="panel-heading">
         Tambah Data
     </div>
     <div class="panel-body">

         <div class="row">
             <div class="col-md-12">

                 <form method="POST">
                     <div class="form-group">
                         <label>Nama</label>
                         <input class="form-control" name="nama" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Username</label>
                         <input class="form-control" name="username" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Password</label>
                         <input class="form-control" name="password" required autocomplete="off"/>
                     </div>

                     <div class="form-group">
                         <label>Level Pengguna</label>
                         <input class="form-control" name="role" required autocomplete="off">
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>

 <?php

    @$nama = $_POST['nama'];
    @$username = $_POST['username'];
    @$password = password_hash($password, PASSWORD_DEFAULT) $_POST['password'];
    @$role = $_POST['role'];
    @$simpan = $_POST['simpan'];

    if ($simpan) {
        $sql = $koneksi->query("insert into data_user(nama,username,password,role)values('$nama','$username','$password','$role')");

        if ($sql) {
    ?>
         <script type="text/javascript">
             alert("Data Berhasil di Simpan");
             window.location.href = "?page=user";
         </script>
 <?php
        }
    }

    ?>