<title>Surat Keterangan Mahasiswa</title>
<h2 class align="center">APLIKASI MANAJEMEN SURAT<br>SMK KP 3 MAJALAYA</h2>
  <div class="row">
                <br><br><div class="col-md-4 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box" style="background: grey;">
                <center>
                  <h3><a href="?page=suratmasuk" class="fa fa-envelope"  style="text-decoration: none; color: white;" ><b>
                  Surat Masuk</a></h3><br>
                  <h4 style="color: white;"><?php echo $hasil_masuk['jumlah']; ?></h4></b>
                </center>
            </div>

  </div>

  <div class ="row">
      <div class="col-md-4 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box" style="background: grey;">        
                <center>
                  <h3><a href="?page=suratkeluar" class="fa fa-envelope"  style="text-decoration: none; color: white;" ><b>
                  Surat keluar</a></h3><br>
                  <h4 style="color: white;"><?php echo $hasil_keluar['jumlah']; ?></h4></b>
                </center>
            </div>
      
  </div>

 <div class ="row">
      <div class="col-md-4 col-sm-6 col-xs-6">           
            <div class="panel panel-back noti-box" style="background: grey;">        
                <center>
                  <h3><a href="?page=user" class="fa fa-user"  style="text-decoration: none; color: white;" ><b>
                  Pengguna</a></h3><br>
                  <h4 style="color: white;"><?php echo $hasil_user['jumlah']; ?></h4></b>
                </center>
            </div>
      </div>
  </div>

     


            <div id="page-inner">
                <div class="row">
                    <div class="col-md-15">
                     <h2></h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
              
             </div>
         </div>
           
                </div>
             </div>
         </div>
      </div>