<?php


$koneksi = new mysqli("localhost", "root", "", "ams2");

$sql_masuk = "SELECT count(*) AS jumlah FROM surat_masuk";
$query_masuk = mysqli_query($koneksi, $sql_masuk);
$hasil_masuk = mysqli_fetch_assoc($query_masuk);

$sql_keluar = "SELECT count(*) AS jumlah FROM surat_keluar";
$query_keluar = mysqli_query($koneksi, $sql_keluar);
$hasil_keluar = mysqli_fetch_assoc($query_keluar);

$sql_user = "SELECT count(*) AS jumlah FROM data_user";
$query_user = mysqli_query($koneksi, $sql_user);
$hasil_user = mysqli_fetch_assoc($query_user);

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>APLIKASI MANAJEMEN SURAT</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
     <?php
    session_start();

    // cek apakah yang mengakses halaman ini sudah login
    if ($_SESSION['role'] == "") {
        header("location:index.php?pesan=gagal");
    }
    ?>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="http://smkkp3mjly.mysch.id/" style="font-size: 20px">SMK KP 3 MAJALAYA</a>
            </div>
            <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;">
<a onclick="return confirm ('Anda Yakin Akan Keluar ?')" href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a>
</div>
</nav>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="text-center ">
                        <img src="assets/picture/supervisor.png" width=100px>
                        <br>Halo, Anda telah login sebagai <b><?php echo $_SESSION['role']; ?></b>.</br>
                        <?php echo date ('d-M-Y'); ?> &nbsp; 
                    </li>
                    <li class ="text-center">
                    </li>

                    <li>
                        <a href="dashboardsupervisor.php"><i class="fa fa-home fa-2x"></i> HOME </a>
                    </li>

                     <li>
                        <a href="?page=suratmasuk"><i class="fa fa-envelope fa-2x"></i>SURAT MASUK </a>
                    </li>

                    <li>
                        <a href="?page=suratkeluar"><i class="fa fa-envelope fa-2x"></i> SURAT KELUAR</a>
                    </li>
                   <li>
                        <a href="?page=user"><i class="fa fa-user fa-2x"></i> PENGGUNA </a>
                    </li>
                    <li>
                        <a href="?page=tentang"><i class="fa fa-info-circle fa-2x"></i> TENTANG </a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
        <div id="page-inner">
        <div class="row">
        <div class="col-md-14">
      <?php

      @$page = $_GET['page'];
      @$aksi = $_GET['aksi'];


      if ($page == "suratmasuk") {
          if ($aksi == "") {
              include "view/supervisor/suratmasuk/suratmasuk.php";
          } elseif ($aksi == "lihat") {
              include "view/supervisor/suratmasuk/lihat.php";
          }

      } elseif ($page == "suratkeluar") {
        if ($aksi == "") {
              include "view/supervisor/suratkeluar/suratkeluar.php";
          } elseif ($aksi == "lihat") {
              include "view/supervisor/suratkeluar/lihat.php";
          }

      } elseif ($page == "user") {
       if ($aksi == "") {
              include "view/supervisor/pengguna/user.php";
          }
          
      } elseif ($page == "tentang") {
       if ($aksi == "") {
              include "view/supervisor/tentang/tentang.php";
          }
          
      }elseif($page==""){
          include"view/supervisor/home.php";
        }



      ?>

                    </div>
                </div>
                <!-- /. ROW  -->
                <hr />

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTables-example').dataTable();
        });
    </script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
</html>

