<div class="row">
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                DATA PENGGUNA
            </div>
           
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Username</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php

                            $no = 1;
                            $sql = $koneksi->query("select * from data_user");
                            while ($data = $sql->fetch_assoc()) {

                            ?>
                                    <td><?=$no++; ?></td>
                                    <td><?=$data['username']; ?></td>                            
                                    <td><?=$data['role']; ?></td>
                                </tr>
                                <?php } ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

