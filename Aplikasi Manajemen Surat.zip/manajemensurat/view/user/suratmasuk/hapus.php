<?php
	
	$id=$_GET ['id'];
	$koneksi->query("delete from surat_masuk where id ='$id'");

?>
<script type="text/javascript">
	window.location.href="?page=suratmasuk";

</script>      