  <?php
    $id=$_GET['id']; 
    @$No_Surat = $_POST['No_Surat'];
    @$Perihal = $_POST['Perihal'];
    @$Asal_Surat = $_POST['Asal_Surat'];
    @$Tgl_Surat = $_POST['Tgl_Surat'];
    @$Tgl_diterima = $_POST['Tgl_diterima'];
    @$Penerima = $_POST['Penerima'];
    @$file = $_POST['File_Surat'];
    @$simpan = $_POST['simpan'];

    @$direktori = "File/Surat Keluar/";
    @$file = $_FILES['File_Surat']['name'];
    @$data = move_uploaded_file($_FILES['File_Surat']['tmp_name'],$direktori.$file);

    if ($simpan) {
        $sql="UPDATE surat_masuk SET No_Surat='$No_Surat', Perihal='$Perihal', Asal_Surat='$Asal_Surat', Tgl_Surat='$Tgl_Surat', Tgl_diterima='$Tgl_diterima', Penerima='$Penerima', File_Surat='$file' WHERE id='$id'";
        $query=mysqli_query($koneksi, $sql);
        $_SESSION['berhasil'] = "Surat masuk berhasil diubah";
        header('location:?page=suratmasuk');
        }
        $sql_read="SELECT * FROM surat_masuk WHERE id='$id'";
        $query_read=mysqli_query($koneksi, $sql_read);
        $row=mysqli_fetch_assoc($query_read);
        ?>

  <div class="panel panel-default">
     <div class="panel-heading">
         Ubah Data Surat Masuk
     </div>
     <div class="panel-body">


         <div class="row">
             <div class="col-md-12">
                
                 <form method="POST" enctype="multipart/form-data">
                     <div class="form-group">
                         <label for="No_Surat">Nomor Surat</label>
                         <input type="text" class="form-control" name=No_Surat value="<?php echo 
                         $row['No_Surat'] ?>" required autocomplete="off"/> 
                     </div>

                     <div class="form-group">
                         <label>Perihal</label>
                         <input class="form-control" name="Perihal" value="<?php echo 
                         $row['Perihal'] ?>" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>Asal Surat</label>
                         <input class="form-control" name="Asal_Surat" value="<?php echo 
                         $row['Asal_Surat'] ?>" required autocomplete="off">
                        </select>
                     </div>

                      <div class="form-group">
                         <label>Tanggal Surat</label>
                         <input class="form-control" name="Tgl_Surat" type="date" value="<?php echo 
                         $row['Tgl_Surat'] ?>" required autocomplete="off"/>
                     </div>

                      <div class="form-group">
                         <label>Tanggal Diterima</label>
                         <input class="form-control" name="Tgl_diterima" type="date" value="<?php echo 
                         $row['Tgl_diterima'] ?>" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>Penerima</label>
                         <input class="form-control" name="Penerima" value="<?php echo 
                         $row['Penerima'] ?>" required autocomplete="off" />
                     </div>

                      <div class="form-group">
                         <label>File Surat</label>
                         <input type="File" class="form-control" name="File_Surat" value="<?php echo $row['File_Surat'] ?>" required autocomplete="off"/> 
                     </div>

                     </div>
                     <div>
                         <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                         <input type="reset" class="btn btn-danger" name="breset" />
                     </div>

             </div>
             </form>
         </div>
     </div>
 </div>
 </div>
       