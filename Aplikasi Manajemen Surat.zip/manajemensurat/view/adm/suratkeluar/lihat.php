<?php 
$id = $_GET['id'];
$sql_read="SELECT * FROM surat_keluar WHERE id = $id";
$query_read=mysqli_query($koneksi, $sql_read);
$row = mysqli_fetch_assoc($query_read);
?>
<!-- Page Content-->
<div class="container-fluid p-0">
<!-- About-->
<section class="resume-section">
<div class="resume-section-content">
<h2>File Surat Keluar</h2>
<p>Nomor Surat : <?php echo $row['No_Surat'];?></p>
<p>Perihal : <?php echo $row['Perihal'];?></p>
<p>Tujuan Surat : <?php echo $row['Tujuan'];?></p>
<p>Tanggal Surat : <?php echo $row['Tgl_Surat'];?></p>
<p>Penanggung Jawab : <?php echo $row['Penanggung_Jawab'];?></p>
<img src="File/<?php echo $row['File_Surat']; ?>" class="imgthumbnail">
</div>
</section>
</div>