<?php
	
	$id=$_GET ['id'];
	$koneksi->query("delete from surat_masuk where id ='$id'");

?>
<script type="text/javascript">
	alert("Data Surat Masuk Berhasil Dihapus")
	window.location.href="?page=suratmasuk";

</script>      