<div class="row">
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                DATA SURAT MASUK
            </div>
            <a href="?page=suratmasuk&aksi=tambah" class="btn btn-primary" style="margin-top: 8px;"><i class="fa fa-plus"></i> Tambah Data </a>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nomor Surat</th>
                                <th>Perihal</th>
                                <th>Asal Surat</th>
                                <th>Tanggal Surat</th>
                                <th>Tanggal Diterima</th>
                                <th>Penerima</th>
                                <th>File Surat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                           <?php

                            $no = 1;
                            $sql = $koneksi->query("select * from surat_masuk");
                            while ($data = $sql->fetch_assoc()) {

                            ?>
                                    <td><?=$no++; ?></td>
                                    <td><?=$data['No_Surat']; ?></td>
                                    <td><?=$data['Perihal']; ?></td>
                                    <td><?=$data['Asal_Surat']; ?></td>
                                    <td><?=$data['Tgl_Surat']; ?></td>
                                    <td><?=$data['Tgl_diterima']; ?></td>
                                    <td><?=$data['Penerima']; ?></td>
                                    <td><?=$data['File_Surat']; ?></td>
                                    <td>
                                        <a href="?page=suratmasuk&aksi=ubah&id=<?php echo $data["id"];?>" class="btn btn-warning"><i class="fa fa-pencil"></i> Ubah </a>
                                        <!--<a href="?page=suratmasuk&aksi=upload&id=<?php echo $data["id"];?>" class="btn btn-success"><i class="fa fa-upload"></i> Upload </a>-->
                                        <a href="?page=suratmasuk&aksi=lihat&id=<?php echo $data["id"];?>" class="btn btn-info"><i class="fa fa-eye"></i> Lihat </a>
                                        <a onclick="return confirm ('Anda yakin akan Menghapus data ini ?')" href="?page=suratmasuk&aksi=hapus&id=<?php echo $data['id']; ?>" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus </a>                                    
                                    </td>
                            </tr>
                             <?php } ?>
                      
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

