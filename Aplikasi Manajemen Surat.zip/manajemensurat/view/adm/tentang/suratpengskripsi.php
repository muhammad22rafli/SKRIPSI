<div class="row">
    <div class="col-md-12">
        <!-- Advanced Tables -->
        <div class="panel panel-default">
            <div class="panel-heading">
                DATA MAHASISWA YANG MENGAJUKAN
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Nim</th>
                                <th>Program Studi</th>
                                <th>Topik</th>
                                <th>Alamat/Instansi Tujuan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                           <?php

                            $no = 1;
                            $sql = $koneksi->query("select * from surat_peng_skripsi");
                            while ($data = $sql->fetch_assoc()) {

                            ?>
                                    <td><?=$no++; ?></td>
                                    <td><?=$data['nama']; ?></td>
                                    <td><?=$data['nim']; ?></td>
                                    <td><?=$data['program_studi']; ?></td>
                                    <td><?=$data['topik']; ?></td>
                                    <td><?=$data['alamat_instansi_tujuan']; ?></td>
                                    <td>
                                        <a href="?page=suratpengskripsi&aksi=hasilsurat&id=<?php echo $data ['id'];?>" class="btn btn-info"><i class="fa fa-eye"></i> Lihat Surat </a>
                                         <a href="https://wa.me/+62<?=$data['no_wa']; ?>" class="btn btn-success" class="fa fa-success" target="_blank">
                                            <i class="fab fa-whatsapp"></i>
                                            <span>Whatsapp</span>
                                        </a>
                                    </td>
                            </tr>
                             <?php } ?>
                      
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

