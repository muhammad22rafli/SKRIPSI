<title>Surat Keterangan Mahasiswa</title>
<h2 class align="center">APLIKASI MANAJEMEN SURAT<br>SMK KP 3 MAJALAYA</h2>
   <div id="page-inner">
                <div class="row">
                    <div class="col-md-15">
                     <h2></h2>   
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                <div class="text-center">
                  <img src="assets/picture/teksma1.png" width="200" height="200">
                </div>
              <div class="container-fluid">
    <div class="text-justify">
    <br>
    <p>Aplikasi Manajemen Surat merupakan aplikasi yang digunakan sebagai sarana pengelolaan administrasi kesekretariatan yang bukan bersifat rahasia, hal tersebut bertujuan untuk menjaga kerahaisaan surat dikarenakan seluruh pegawai dapat mengakses Aplikasi Manajemen Surat.
        Aplikasi Manajemen Surat ini dibuat berdasarkan hasil observasi yang dilakukan oleh pengembang yang dilaksanakan di SMK KP 3 Majalaya. Adapun pengembangan dilakukan dengan menambahkan beberapa fitur yang belum ada di aplikasi sebelumnya. Fitur yang dikembangkan antara lain:
        <p>- Fitur Pencarian Data   
        <br>- Fitur Pembagian Hak Akses
        <br>- Fitur Penyimpanan Berkas Digital 
        <br>- Fitur Pengelolaan Akun</br></p>
        <p> Aplikasi ini dibuat terkait dengan penelitian yang dilakukan oleh Muhammad Rafli sebagai pengembang dan peneliti, yang tujuan penelitiannya untuk mengimplementasikan ilmu yang dipelajarinya dalam bidang web terhadap proses administrasi kesekretariatan yang ada di SMK KP 3 Majalaya.</p>

        
    </p><br>
 </div>
 </div>
             </div>
         </div>
           
                </div>
             </div>
         </div>
      </div>