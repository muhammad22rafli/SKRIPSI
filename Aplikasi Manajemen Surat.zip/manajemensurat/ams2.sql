-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2021 at 02:18 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ams2`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_user`
--

CREATE TABLE IF NOT EXISTS `data_user` (
`id` int(11) NOT NULL,
  `nama` varchar(10) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` enum('admin','user','supervisor','') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_user`
--

INSERT INTO `data_user` (`id`, `nama`, `username`, `password`, `role`) VALUES
(1, 'Deden', 'admin', 'admin', 'admin'),
(4, 'Deni', 'user', 'user', 'user'),
(5, '', 'supervisor', 'supervisor', 'supervisor'),
(6, 'Andi', 'user1', 'user1', 'user'),
(7, 'Asri', 'admin1', 'admin1', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `surat_keluar`
--

CREATE TABLE IF NOT EXISTS `surat_keluar` (
`id` int(10) NOT NULL,
  `No_Surat` varchar(50) NOT NULL,
  `Perihal` varchar(50) NOT NULL,
  `Tujuan` varchar(50) NOT NULL,
  `Tgl_Surat` date NOT NULL,
  `Penanggung_Jawab` varchar(50) NOT NULL,
  `File_Surat` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `surat_keluar`
--

INSERT INTO `surat_keluar` (`id`, `No_Surat`, `Perihal`, `Tujuan`, `Tgl_Surat`, `Penanggung_Jawab`, `File_Surat`) VALUES
(11, '007/KP3/VI/2021', 'Pemberitahuan', 'Orang Tua Siswa', '2021-06-02', 'Deden Fauzi, S.T.', '6.PNG'),
(13, '008/KP3/VI/2021', 'Undangan', 'Orang Tua Siswa', '2021-06-24', 'Deden Fauzi, S.T.', 'Undangan.PNG'),
(16, '014/KP3/VII/2021', 'Undangan', 'Guru SMK KP 3 Majalaya', '2021-07-12', 'Deden Fauzi, S.T.', 'Undangan Guru.PNG'),
(17, '009/KP3/VII/2021', 'Undangan', 'Guru SMK KP 3 Majalaya', '2021-07-05', 'Deden Fauzi, S.T.', 'Undangan Guru.PNG'),
(18, '010/KP3/VII/2021', 'Pemberitahuan', 'Orang Tua Siswa', '2021-07-25', 'Solehudin, M.Pd.', 'Pemberitahuan.PNG'),
(19, '011/KP3/VIII/2021', 'Undangan', 'Orang Tua Siswa', '2021-08-05', 'Deden Fauzi, S.T.', 'Undangan.PNG'),
(20, '013/KP3/VIII/2021', 'Perizinan', 'Ketua Yayasan', '2021-08-10', 'Deden Fauzi, S.T.', 'Perizinan.PNG'),
(21, '015/KP3/VII/2021', 'Undangan', 'Ketua Yayasan', '2021-08-12', 'Deden Fauzi, S.T.', 'Undangan.PNG'),
(22, '016/KP3/IX/2021', 'Pemberitahuan', 'Guru SMK KP 3 Majalaya', '2021-09-01', 'Sumarna', 'Pemberitahuan.PNG'),
(23, '017/KP3/VIII/2021', 'Undangan', 'Ketua Yayasan', '2021-07-18', 'Deden Fauzi', 'Undangan.PNG'),
(24, '018/KP3/IX/2021', 'Perizinan', 'Orang Tua Siswa', '2021-09-09', 'Sumarna', 'Perizinan.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `surat_masuk`
--

CREATE TABLE IF NOT EXISTS `surat_masuk` (
`id` int(10) NOT NULL,
  `No_Surat` varchar(50) NOT NULL,
  `Perihal` varchar(50) NOT NULL,
  `Asal_Surat` varchar(50) NOT NULL,
  `Tgl_Surat` date NOT NULL,
  `Tgl_diterima` date NOT NULL,
  `Penerima` varchar(50) NOT NULL,
  `File_Surat` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `surat_masuk`
--

INSERT INTO `surat_masuk` (`id`, `No_Surat`, `Perihal`, `Asal_Surat`, `Tgl_Surat`, `Tgl_diterima`, `Penerima`, `File_Surat`) VALUES
(39, '002/OSIS/VI/2021', 'Perizinan', 'OSIS SMK KP 3 Majalaya', '2021-06-01', '2021-06-02', 'Sumarna', '4.PNG'),
(53, '020/KP1/VI/2021', 'Undangan', 'SMA KP 1 Paseh', '2021-06-11', '2021-06-13', 'Sumarna', '7.PNG'),
(61, '003/OSIS/TEKSMA/VI/2021', 'Undangan', 'OSIS SMK KP 3 Majalaya', '2021-06-20', '2021-06-20', 'Deden', 'SAMPLESURAT.docx'),
(62, '012/KP2/VI/2021', 'Undangan', 'SMK KP 2 Majalaya', '2021-06-21', '2021-06-22', 'Sumarna', 'Undangan.PNG'),
(63, '023/KP1/VII/2021', 'Undangan', 'SMA KP 1 Paseh', '2021-07-06', '2021-07-07', 'Deden', ''),
(74, '001/OSIS/TEKSMA/VII/2020', 'Undangan', 'OSIS SMK KP 3 Majalaya', '2021-06-01', '2021-06-02', 'Sumarna', ''),
(75, '002/OSIS/TEKSMA/VI/2021', 'Perizinan', 'OSIS SMK KP 3 Majalaya', '2021-06-01', '2021-06-02', 'Sumarna', 'Perizinan OSIS.PNG'),
(76, '002/KP2/VI/2021', 'Undangan', 'SMK KP 2 Majalaya', '2021-06-02', '2021-06-04', 'Deden', 'Rapat.PNG'),
(77, '003/OSIS/TEKSMA/VII/2020', 'Undangan', 'OSIS SMK KP 3 Majalaya', '2021-07-10', '2021-07-11', 'Sumarna', 'Undangan Guru.PNG'),
(78, '004/OSIS/TEKSMA/VII/2020', 'Undangan', 'OSIS SMK KP 3 Majalaya', '2021-07-07', '2021-07-09', 'Deden', 'Undangan Guru.PNG'),
(80, '021231', 'Undangan', 'kp 3 majalaya', '2021-07-21', '2021-07-21', 'Sumarna', '1.PNG'),
(81, '014/OSIS/TEKSMA/VII/2020', 'Perizinan', 'OSIS SMK KP 3 Majalaya', '2021-07-20', '2021-07-21', 'Andri', 'Perizinan.PNG'),
(82, '019/KP3/IX/2021', 'Pemberitahuan', 'SMK KP 3 Majalaya', '2021-09-10', '2021-09-11', 'Asri', 'Pemberitahuan.PNG'),
(83, '020/KP3/IX/2021', 'Undangan', 'SMK KP 3 Majalaya', '2021-09-08', '2021-09-10', 'Cecep', 'Undangan.PNG'),
(84, '021/KP3/IX/2021', 'Undangan', 'SMK KP 3 Majalaya', '2021-09-11', '2021-09-12', 'Andri', 'Undangan.PNG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_user`
--
ALTER TABLE `data_user`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surat_keluar`
--
ALTER TABLE `surat_keluar`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_user`
--
ALTER TABLE `data_user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `surat_keluar`
--
ALTER TABLE `surat_keluar`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `surat_masuk`
--
ALTER TABLE `surat_masuk`
ADD CONSTRAINT `surat_masuk_ibfk_1` FOREIGN KEY (`id`) REFERENCES `surat_masuk` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
